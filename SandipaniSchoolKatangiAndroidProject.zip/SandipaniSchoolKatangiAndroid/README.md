# Sandipani School Katangi — Android Demo Project

A local, offline-capable Android WebView wrapper around the demo portal.

## Demo login
- Choose Student, Teacher, or Admin.
- Password for all three demo roles: `Cm rise`
- Use fictional names only (e.g. Demo Student / Demo Teacher / Demo Admin).

## Important
This is a proposal/demo, not an official school app and not connected to school records.
All attendance, marks, homework, notices, profiles, and sample lists are fictional.
Do not enter real student data, teacher data, phone numbers, or real passwords.
Replace school branding/photos only after receiving school permission.

## Build APK (requires a computer with Android Studio)
1. Install Android Studio.
2. Open this project folder (`SandipaniSchoolKatangiAndroid`) in Android Studio.
3. Allow Gradle sync and install any prompted Android SDK Platform 35 / Build Tools.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When build completes, click Locate. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that file manager.

## Mobile-only note
Android Studio is not available on Android phones. This project source can be stored/shared from a phone, but compiling a native APK generally needs Android Studio or a compatible cloud build service. The HTML demo can also be opened in a mobile browser, but that is not the installable APK.

## Project structure
- `app/src/main/java/.../MainActivity.kt` — native Android WebView host
- `app/src/main/assets/index.html` — all demo screens and local demo behavior
- `app/src/main/AndroidManifest.xml` — app entry point
